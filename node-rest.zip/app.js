const dotenv = require('dotenv');
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();

const usersRoutes = require('./routes/users');

dotenv.config();

//MIDLEWARES
app.use(bodyParser.json());
app.use('/users', usersRoutes);

//ROUTES
app.get('/', (req, res) => {
    res.send('Hello world');
});

//DB
mongoose.connect(process.env.DB_CONNECTION, () => {
    console.log('connected to db');
})


//INIT
app.listen(3000);