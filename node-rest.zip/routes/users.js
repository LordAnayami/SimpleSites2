const express = require("express");
const router = express.Router();
const Users = require("../models/User");
//CREATE
router.post("/", (req, res) => {
  console.log(req.body);
  const user = new Users({
    name: req.body.name,
    description: req.body.description,
  });
  user
    .save()
    .then((data) => {
      res.json(data);
    })
    .catch((err) => {
 console.log("err ", err);
      res.json({ message: err });
    });
});

// let users = require("../models/User");

// CREATE
// router.post('/', (req, resp)=>{
//  console.log("req ", req.body);
//  resp.json(req.body);
// })

// READ ALL
router.get('/', (req, resp) => {
  resp.send('Users get');
})

// READ ONE BY ID
router.get('/:id', function(req, resp){
  resp.send('User id:' + req.params.id);
})

// UPDATE
router.put('/', (req, resp)=>{
  console.log("req ", req.body);
  resp.json(req.body);
})

// DELETE
router.delete('/:id', function(req, resp){
  resp.send('User id:' + req.params.id);
})


// export module
module.exports = router;






//GET ALL
router.get("/", async (req, res) => {
  try {
    const user = await Users.find();
    res.json(user);
  } catch (error) {
    res.json({ message: error });
  }
});

//FIND
router.get("/:id", async (req, res) => {
  console.log(req.params.id);
  try {
    const user = await Users.findById(req.params.id);
    res.json(user);
  } catch (error) {
    res.json({ message: error });
  }
});

//ADD
// router.post("/", (req, res) => {
//   console.log(req.body);
//   const user = new Users({
//     title: req.body.title,
//   });
//   user
//     .save()
//     .then((data) => {
//       res.json(data);
//     })
//     .catch((err) => {
//       res.json({ message: err });
//     });
// });

//ADD
router.post("/single", async (req, res) => {
  const user = new Users({
    title: req.body.title,
    description: req.body.description,
  });
  try {
    const savedUser = await user.save();
    res.json(savedUser);
  } catch (err) {
    res.json({ message: err });
  }
});

//UPDATE
router.put("/:id", async (req, res) => {
    const user = new Users({
      title: req.body.title,
      description: req.body.description,
    });
    try {
      const updatedUser = await user.updateOne({_id: req.params.id}, {$set: {title: req.body.title}});
      res.json(updatedUser);
    } catch (err) {
      res.json({ message: err });
    }
  });

// DELETE
router.delete("/:id", async (req, res) => {
    console.log(req.params.id);
    try {
      const user = await Users.remove({_id: req.params.id});
      res.json(user);
    } catch (error) {
      res.json({ message: error });
    }
  });



module.exports = router;
